#usage - filename <RowItems - Spp names> <Families> <outputfile>


# usage -AddTab <number of tabs required> <outputfile>
AddTab(){
   tabCount=$1
   outputfile=$2
   val=0
   
    while [ $val -le $tabCount ]
    do
        printf "\t" >> $outputfile
       val=`expr $val + 1`
    done
}

#declaring local variables
Row=0
RowCount=0
declare -a RowItems
count=0

while read name
do
    
    #adding one tab
    AddTab 1 $3
    
    #saving readed name to array
    RowItems[$Row]=$name
    
    #incrementing the counters
    Row=`expr $Row + 1`
    RowCount=`expr $RowCount + 1` #this counter will be used in the below
    
    #populating first line
    printf "%s" $name >> $3

done < $1


    printf "\n" >> $3

    while read familyItem
    do
    
    printf "%s" $familyItem >> $3
    AddTab 1 $3

    count=0
        while [ $count -lt $RowCount ]
        do
            filename=${RowItems[$count]}
            grepcout=`grep -c $familyItem $filename`
            
            printf "%d" $grepcout >> $3
            
            AddTab 1 $3
            count=`expr $count + 1`
        done
    
    printf "\n" >> $3
    done < $2




